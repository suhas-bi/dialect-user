<header class="navbar">
    <div class="header-signup container-fluid navbar-default d-flex">
        <div class="container">
        <div class="logo">
            <a href="{{ url('/') }}"><img src="{{ asset('assets/images/logo-signup.png') }}" alt="XCHANGE"></a>
        </div>
        </div>
    </div>
</header>